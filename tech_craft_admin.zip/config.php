<?php

$host ="localhost";
$user ="techcraf";
$password="mQ0kh06x8R";
$dbname="techcraf_tech_craft";

$connection=mysqli_connect($host,$user,$password,$dbname);
//  if($connection){
//    echo "connected";
//  }
// else {
//   echo "not connected";
// }

 ?>
