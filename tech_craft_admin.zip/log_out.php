<?php

      session_start();
   unset($_SESSION['a_n']);

     header("Location: admin.php");
 ?>
