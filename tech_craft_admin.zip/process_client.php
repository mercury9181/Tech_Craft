<?php
require_once 'config.php';


$client_name=$_POST['client_name'];




$query_admin="INSERT INTO clients VALUES('','$client_name')";

$send_admin=mysqli_query($connection,$query_admin);

if ($send_admin) {
 header("Location: admin_page.php?client=success");

}
else {
  echo "not inserted employee<br>";
}




 ?>
