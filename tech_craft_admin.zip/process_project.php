<?php
require_once 'config.php';

$project_name=$_POST['project_name'];
$client_name=$_POST['client_name'];
$service_type=$_POST['service_type'];
$project_details=$_POST['project_details'];




$query_admin="INSERT INTO project VALUES('','$project_name','$client_name','$service_type','$project_details')";

$send_admin=mysqli_query($connection,$query_admin);

if ($send_admin) {
 header("Location: admin_page.php?project=success");

}
else {
  echo "not inserted employee<br>";
}

// finish employee








 ?>
